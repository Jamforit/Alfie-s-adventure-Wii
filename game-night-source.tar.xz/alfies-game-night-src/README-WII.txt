ALFIE'S GAME NIGHT - NINTENDO WII

UPLOADING WITH WIiXPLORER VIA FTP (iPHONE):
1. In WiiXplorer go to the SD card and turn on the FTP server.
2. On your phone, connect your FTP app to the Wii's IP address.
3. Place the full folder 'alfies-game-night' in SD:/apps/
4. In Homebrew Channel launch 'Alfie's Game Night'.
5. Keep the original Alfie's Adventure folder as a separate Wii app.

USE:
Wii Remote sideways. Press 2 to roll and play; D-pad to move in Bone Catch.
Kacey is player 1, Darcey player 2. Player 3 and 4 are extra players.
Any player without a connected remote is controlled by the Wii.
HOME exits; MINUS returns to the title. First to three golden bones wins.

Note: This is a native Wii Homebrew Channel application, not a Wii disc or ISO.
