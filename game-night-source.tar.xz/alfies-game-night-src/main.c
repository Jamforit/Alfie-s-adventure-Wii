// Alfie's Game Night - 3D family board game + mini games (libogc / devkitPPC)
#include <gccore.h>
#include <wiiuse/wpad.h>
#include <asndlib.h>
#include <math.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#define RATE 32000
#define NT 18
#define NEED 3          // golden bones to win
#define COST 6          // coins per golden bone
typedef struct { u8 r, g, b; } C;
// ---- Alfie + player looks (edit freely) ----
static const C FUR={214,160,92}, EAR={150,98,52}, CHEST={250,244,232};
static const C PC[4]={{230,60,60},{60,120,235},{60,190,90},{240,190,40}};
static const C HC[4]={{70,40,20},{20,20,25},{200,140,50},{150,60,30}};
static const C TC[4]={{70,120,230},{220,60,60},{255,200,50},{170,90,220}};
static const C SKIN={255,214,170}, DARK={30,25,25}, WHITE={255,255,255}, GOLD={255,205,60};

static void *xfb[2]; static int fb; static GXRModeObj *rm; static unsigned fr;
// ================= 3D drawing =================
static void v3(float x,float y,float z,float s,C c){ GX_Position3f32(x,y,z); GX_Color4u8((u8)(c.r*s),(u8)(c.g*s),(u8)(c.b*s),255); }
static void boxY(float x,float y,float z,float w,float h,float d,float a,C c){
    float ca=cosf(a),sa=sinf(a),hx=w/2,hz=d/2,X[4],Z[4];
    static const float kx[4]={-1,1,1,-1},kz[4]={-1,-1,1,1};
    for(int i=0;i<4;i++){ X[i]=x+kx[i]*hx*ca-kz[i]*hz*sa; Z[i]=z+kx[i]*hx*sa+kz[i]*hz*ca; }
    GX_Begin(GX_QUADS,GX_VTXFMT0,24);
    for(int i=0;i<4;i++) v3(X[i],y+h,Z[i],1.0f,c);
    for(int i=0;i<4;i++) v3(X[i],y,Z[i],0.4f,c);
    for(int i=0;i<4;i++){ int j=(i+1)&3; float s=0.6f+0.1f*i;
        v3(X[i],y,Z[i],s,c); v3(X[j],y,Z[j],s,c); v3(X[j],y+h,Z[j],s,c); v3(X[i],y+h,Z[i],s,c); }
    GX_End();
}
static void box(float x,float y,float z,float w,float h,float d,C c){ boxY(x,y,z,w,h,d,0,c); }
static void part(float x,float y,float z,float a,float ox,float oy,float oz,float w,float h,float d,C c){
    float ca=cosf(a),sa=sinf(a); boxY(x+ox*ca-oz*sa,y+oy,z+ox*sa+oz*ca,w,h,d,a,c);
}
static void mii(float x,float y,float z,float a,int p,float run,int cheer){   // Mii-style avatar
    float sw=sinf(run)*0.18f, up=cheer?0.45f:0.0f; C pants={50,60,110};
    part(x,y,z,a,-0.13f,0,sw,0.2f,0.5f,0.22f,pants); part(x,y,z,a,0.13f,0,-sw,0.2f,0.5f,0.22f,pants);
    part(x,y,z,a,0,0.5f,0,0.55f,0.5f,0.3f,PC[p]);
    part(x,y,z,a,-0.36f,0.5f+up*0.5f,-sw*0.6f,0.14f,0.45f,0.18f,SKIN); part(x,y,z,a,0.36f,0.5f+up*0.5f,sw*0.6f,0.14f,0.45f,0.18f,SKIN);
    part(x,y,z,a,0,1.0f,0,0.5f,0.48f,0.42f,SKIN);
    part(x,y,z,a,0,1.4f,-0.02f,0.54f,0.2f,0.46f,HC[p]);
    part(x,y,z,a,-0.12f,1.2f,0.22f,0.07f,0.09f,0.03f,DARK); part(x,y,z,a,0.12f,1.2f,0.22f,0.07f,0.09f,0.03f,DARK);
    part(x,y,z,a,0,1.08f,0.22f,0.14f,0.04f,0.03f,(C){200,60,60});
}
static void alfie3d(float x,float y,float z,float a,float run,int happy){
    float sw=sinf(run)*0.1f, wag=sinf(fr*(happy?0.7f:0.3f))*0.12f;
    part(x,y,z,a,-0.15f,0,-0.3f+sw,0.13f,0.35f,0.13f,FUR); part(x,y,z,a,0.15f,0,-0.3f-sw,0.13f,0.35f,0.13f,FUR);
    part(x,y,z,a,-0.15f,0,0.3f-sw,0.13f,0.35f,0.13f,FUR); part(x,y,z,a,0.15f,0,0.3f+sw,0.13f,0.35f,0.13f,FUR);
    part(x,y,z,a,0,0.3f,0,0.5f,0.4f,0.9f,FUR); part(x,y,z,a,0,0.3f,0.25f,0.52f,0.3f,0.2f,CHEST);
    part(x,y,z,a,0,0.5f,0.55f,0.4f,0.4f,0.4f,FUR); part(x,y,z,a,0,0.5f,0.82f,0.2f,0.16f,0.2f,CHEST);
    part(x,y,z,a,0,0.58f,0.94f,0.09f,0.08f,0.05f,DARK);
    part(x,y,z,a,-0.13f,0.66f,0.7f,0.06f,0.06f,0.03f,DARK); part(x,y,z,a,0.13f,0.66f,0.7f,0.06f,0.06f,0.03f,DARK);
    part(x,y,z,a,-0.23f,0.45f,0.52f,0.1f,0.3f,0.16f,EAR); part(x,y,z,a,0.23f,0.45f,0.52f,0.1f,0.3f,0.16f,EAR);
    part(x,y,z,a,wag,0.55f,-0.55f,0.1f,0.1f,0.35f,EAR);
    part(x,y,z,a,0,0.4f,0.62f,0.42f,0.05f,0.1f,(C){220,40,50});
}
static void bone3d(float x,float y,float z,float a,float s,C c){
    part(x,y,z,a,0,0,0,0.9f*s,0.18f*s,0.18f*s,c);
    for(int i=0;i<4;i++) part(x,y,z,a,(i&1?0.5f:-0.5f)*s,0,(i&2?0.1f:-0.1f)*s,0.2f*s,0.2f*s,0.2f*s,c);
}
// ================= 2D overlay + text =================
static void rect2(float x,float y,float w,float h,C c){
    GX_Begin(GX_QUADS,GX_VTXFMT0,4);
    GX_Position3f32(x,y,0);GX_Color4u8(c.r,c.g,c.b,255); GX_Position3f32(x+w,y,0);GX_Color4u8(c.r,c.g,c.b,255);
    GX_Position3f32(x+w,y+h,0);GX_Color4u8(c.r,c.g,c.b,255); GX_Position3f32(x,y+h,0);GX_Color4u8(c.r,c.g,c.b,255); GX_End();
}
static const char CH[]="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ!-+:";
static const u8 FT[][5]={{7,5,5,5,7},{2,6,2,2,7},{7,1,7,4,7},{7,1,7,1,7},{5,5,7,1,1},{7,4,7,1,7},{7,4,7,5,7},{7,1,1,1,1},{7,5,7,5,7},{7,5,7,1,7},
{2,5,7,5,5},{6,5,6,5,6},{3,4,4,4,3},{6,5,5,5,6},{7,4,6,4,7},{7,4,6,4,4},{3,4,5,5,3},{5,5,7,5,5},{7,2,2,2,7},{1,1,1,5,2},{5,5,6,5,5},{4,4,4,4,7},{5,7,7,5,5},{6,5,5,5,5},{2,5,5,5,2},{6,5,6,4,4},{2,5,5,6,3},{6,5,6,5,5},{3,4,2,1,6},{7,2,2,2,2},{5,5,5,5,7},{5,5,5,5,2},{5,5,7,7,5},{5,5,2,5,5},{5,5,2,2,2},{7,1,2,4,7},
{2,2,2,0,2},{0,0,7,0,0},{0,2,7,2,0},{0,2,0,2,0}};
static void text(const char*s,float x,float y,float sc,C c){
    for(;*s;s++,x+=4*sc){ char ch=*s; if(ch>='a'&&ch<='z') ch-=32; const char*p=strchr(CH,ch); if(!p) continue;
        int i=p-CH; for(int r=0;r<5;r++) for(int k=0;k<3;k++) if(FT[i][r]&(4>>k)) rect2(x+k*sc,y+r*sc,sc,sc,c); }
}
static void ctext(const char*s,float y,float sc,C c){ text(s,320-strlen(s)*2*sc,y,sc,c); }
// ================= sound =================
typedef struct { s16*b; int bytes; } Snd;
static Snd tune(const float*n,int cnt,int ms,int wave,float vol,int slide){
    int per=RATE*ms/1000,tot=per*cnt; Snd s; s.bytes=((tot*2)+31)&~31; s.b=(s16*)memalign(32,s.bytes); memset(s.b,0,s.bytes); float ph=0;
    for(int k=0;k<cnt;k++){ if(n[k]<=0) continue;
        for(int i=0;i<per;i++){ float t=(float)i/per, f=n[k]*(slide>0?1+0.8f*t:slide<0?1-0.5f*t:1);
            ph+=f/RATE; ph-=(int)ph;
            float v=wave==0?(ph<0.5f?1.f:-1.f):wave==1?sinf(6.2831853f*ph):wave==2?((rand()&255)/128.f-1.f):(ph<0.5f?ph*4-1:3-ph*4);
            float env=(i<150?i/150.f:1.f)*(1.f-0.6f*t); s.b[k*per+i]=(s16)(v*env*vol*32000); } }
    return s;
}
static Snd mix(Snd a,Snd b){ int n=a.bytes/2; for(int i=0;i<n;i++){ int v=a.b[i]+b.b[i]; a.b[i]=v>32000?32000:v<-32000?-32000:v; } free(b.b); DCFlushRange(a.b,a.bytes); return a; }
static Snd S_roll,S_step,S_coin,S_bad,S_bone,S_win,S_bark,S_beep,S_go,S_hit,S_music1,S_music2;
static int nv=1,curMusic=-1;
static void play(Snd s,int vol){ int v=nv; nv=nv%8+1; ASND_StopVoice(v); ASND_SetVoice(v,VOICE_MONO_16BIT,RATE,0,s.b,s.bytes,vol,vol,NULL); }
static void music(int m){ if(m==curMusic) return; curMusic=m; ASND_StopVoice(0); Snd s=m?S_music2:S_music1; ASND_SetInfiniteVoice(0,VOICE_MONO_16BIT,RATE,0,s.b,s.bytes,100,100); }
static Snd song(const float*mel,const float*root,int ms,float mv,float bv){
    float bass[32]; for(int i=0;i<32;i++) bass[i]=(i&1)?0:root[i/8];
    return mix(tune(mel,32,ms,3,mv,0),tune(bass,32,ms,0,bv,0));
}
static void initSound(void){
    ASND_Init(); ASND_Pause(0);
    float roll[10],st[]={700},co[]={988,1319,1568},bad[]={300,220,160},bo[]={523,659,784,1047},wn[]={523,659,784,1047,0,784,1047,1319,1568,1568},
          bk[]={420},be[]={880},go[]={1320,1760},ht[]={150};
    for(int i=0;i<10;i++) roll[i]=300+(rand()%500);
    S_roll=tune(roll,10,35,2,0.2f,0); S_step=tune(st,1,60,1,0.35f,1); S_coin=tune(co,3,70,0,0.2f,0);
    S_bad=tune(bad,3,110,3,0.4f,-1); S_bone=tune(bo,4,80,0,0.22f,0); S_win=tune(wn,10,140,0,0.25f,0);
    S_bark=tune(bk,1,120,2,0.5f,-1); S_beep=tune(be,1,150,1,0.5f,0); S_go=tune(go,2,200,0,0.3f,0); S_hit=tune(ht,1,100,2,0.5f,-1);
    float m1[]={523,659,784,659,880,784,659,523,587,698,880,698,784,659,587,0,523,659,784,1047,880,784,659,784,698,659,587,523,587,659,523,0},r1[]={262,294,262,349};
    float m2[]={440,523,659,523,440,523,659,880,392,494,587,494,392,494,587,784,349,440,523,440,349,440,523,698,330,415,494,415,330,494,659,0},r2[]={220,196,175,165};
    S_music1=song(m1,r1,230,0.07f,0.06f); S_music2=song(m2,r2,130,0.07f,0.07f);
    DCFlushRange(S_roll.b,S_roll.bytes);DCFlushRange(S_step.b,S_step.bytes);DCFlushRange(S_coin.b,S_coin.bytes);DCFlushRange(S_bad.b,S_bad.bytes);
    DCFlushRange(S_bone.b,S_bone.bytes);DCFlushRange(S_win.b,S_win.bytes);DCFlushRange(S_bark.b,S_bark.bytes);DCFlushRange(S_beep.b,S_beep.bytes);
    DCFlushRange(S_go.b,S_go.bytes);DCFlushRange(S_hit.b,S_hit.bytes);
}
// ================= game state =================
typedef struct { int tile,coins,bones,human; } Pl;
static Pl pl[4];
enum{ST_TITLE,ST_ROLL,ST_MOVE,ST_TILE,ST_INTRO,ST_MINI,ST_RES,ST_WIN};
static int st,stT,cur,rnd,dice,steps,hop,mg,winner,rank_[4];
static u32 held[4],down[4];
static char msg[64];
static const int TT[NT]={2,0,0,3,1,0,0,3,0,2,0,1,0,3,0,0,1,0};   // 0 blue +3, 1 red -2, 2 bone shop, 3 lucky
static float cx=0,cz=0;
static float mt,mpos[4],mv[4],mlk[4][3],merr[4],msc[4]; static int mact[4],matt[4]; static u8 cgot[4][24];
static const char*PN[4]={"KACEY","DARCEY","PLAYER 3","PLAYER 4"};
static const char*MGN[3]={"FETCH RACE","BONE CATCH","BARK TIMING"};
static const char*MGH[3]={"MASH 2 TO RUN! FIRST TO THE LINE WINS","MOVE LEFT RIGHT. CATCH BONES AVOID SOCKS","PRESS 2 WHEN THE MARKER HITS THE MIDDLE"};
#define ACT (WPAD_BUTTON_2|WPAD_BUTTON_A|WPAD_BUTTON_1)
#define LEFTB (WPAD_BUTTON_UP|WPAD_BUTTON_LEFT)
#define RIGHTB (WPAD_BUTTON_DOWN|WPAD_BUTTON_RIGHT)

static void tpos(int i,float*x,float*z){ int a,b; if(i<6){a=i;b=0;}else if(i<10){a=5;b=i-5;}else if(i<15){a=14-i;b=4;}else{a=0;b=18-i;}
    *x=(a-2.5f)*2.4f; *z=(b-2.0f)*2.4f; }
static void say(const char*s){ strncpy(msg,s,63); msg[63]=0; }
static void newGame(void){ for(int p=0;p<4;p++){ pl[p].tile=0; pl[p].coins=3; pl[p].bones=0; } cur=0; rnd=1; st=ST_ROLL; stT=0; say("ROLL THE DICE!"); music(0); }
static int isAct(int p){ return pl[p].human?(down[p]&ACT):0; }
static void giveBone(int p){ pl[p].coins-=COST; pl[p].bones++; play(S_bone,255); snprintf(msg,64,"%s GOT A GOLDEN BONE!",PN[p]); if(pl[p].bones>=NEED){ winner=p; st=ST_WIN; stT=0; play(S_win,255); } }

static void startMini(void){
    mt=0; memset(mpos,0,sizeof mpos); memset(mv,0,sizeof mv); memset(merr,0,sizeof merr); memset(msc,0,sizeof msc);
    memset(mact,0,sizeof mact); memset(matt,0,sizeof matt); memset(cgot,0,sizeof cgot); memset(mlk,0,sizeof mlk);
}
static int itemType(int k){ return k%4==3; }
static float itemCol(int k){ return (float)(((k*7+3)%5)-2)*1.1f; }
static float itemY(int k,float t){ return 12.f-(t-(k*42+40))*0.12f; }
static int miniUpdate(void){      // returns 1 when finished
    mt++;
    if(mg==0){ int done=0;
        for(int p=0;p<4;p++){ if(pl[p].human?(down[p]&ACT):(rand()%100<9+(p*7+rnd)%4)) mv[p]+=0.04f; mpos[p]+=mv[p]; mv[p]*=0.94f; msc[p]=mpos[p]; if(mpos[p]>=50) done=1; }
        return done||mt>1500;
    }
    if(mg==1){
        for(int p=0;p<4;p++){ if(mact[p]>0){ mact[p]--; continue; }
            if(pl[p].human){ if(held[p]&LEFTB) mpos[p]-=0.16f; if(held[p]&RIGHTB) mpos[p]+=0.16f; }
            else { float best=99,tg=mpos[p]; for(int k=0;k<24;k++){ float y=itemY(k,mt); if(mt>k*42+40 && y>1.0f && y<best && !itemType(k)){ best=y; tg=itemCol(k);} }
                   float d=tg-mpos[p]; mpos[p]+=d>0.15f?0.12f+0.01f*p:d<-0.15f?-(0.12f+0.01f*p):0; }
            if(mpos[p]<-2.6f) mpos[p]=-2.6f; if(mpos[p]>2.6f) mpos[p]=2.6f;
            for(int k=0;k<24;k++){ float y=itemY(k,mt); if(!cgot[p][k]&&mt>k*42+40&&y<1.3f&&y>0.1f&&fabsf(mpos[p]-itemCol(k))<0.9f){
                cgot[p][k]=1; if(itemType(k)){ msc[p]-=1; mact[p]=40; play(S_hit,150);} else { msc[p]+=1; play(S_coin,pl[p].human?200:80);} } }
        }
        return mt>24*42+150;
    }
    int all=1;
    for(int p=0;p<4;p++){ if(matt[p]>=3) continue; all=0;
        float sp=0.05f+0.02f*matt[p]+p*0.004f, m=sinf(mt*sp)*3; int press=0;
        if(mact[p]>0) mact[p]--;
        if(pl[p].human) press=down[p]&ACT; else if(mact[p]==0 && fabsf(m)<0.2f+0.12f*((p+rnd)%3)){ press=1; mact[p]=50; }
        if(press){ mlk[p][matt[p]]=m; merr[p]+=fabsf(m); matt[p]++; play(S_step,200); } }
    for(int p=0;p<4;p++) msc[p]=-(merr[p]+(3-matt[p])*3.f);
    return all||mt>1500;
}
static void rankAndPay(void){
    static const int pay[4]={5,3,2,1};
    for(int p=0;p<4;p++){ int r=0; for(int q=0;q<4;q++) if(msc[q]>msc[p]||(msc[q]==msc[p]&&q<p)) r++; rank_[p]=r; pl[p].coins+=pay[r]; }
}
static void update(void){
    stT++;
    switch(st){
    case ST_TITLE: for(int p=0;p<4;p++) if(down[p]&ACT){ newGame(); return; } break;
    case ST_ROLL:
        if(isAct(cur)||(!pl[cur].human&&stT>50)){ dice=1+rand()%6; steps=dice; hop=-30; st=ST_MOVE; stT=0; play(S_roll,255); snprintf(msg,64,"P%d ROLLS...",cur+1); } break;
    case ST_MOVE:
        hop++; if(hop==0){ snprintf(msg,64,"P%d ROLLED A %d!",cur+1,dice); play(S_bark,160); }
        if(hop>=14){ hop=0; pl[cur].tile=(pl[cur].tile+1)%NT; steps--; play(S_step,230);
            if(TT[pl[cur].tile]==2 && pl[cur].coins>=COST){ giveBone(cur); if(st==ST_WIN) return; }
            if(steps==0){ st=ST_TILE; stT=0; } } break;
    case ST_TILE:
        if(stT==1){ int t=TT[pl[cur].tile],c=pl[cur].coins;
            if(t==0){ pl[cur].coins+=3; say("BLUE SPACE +3 COINS"); play(S_coin,255); }
            else if(t==1){ pl[cur].coins=c>=2?c-2:0; say("RED SPACE -2 COINS"); play(S_bad,255); }
            else if(t==3){ int g=1+rand()%5; pl[cur].coins+=g; snprintf(msg,64,"LUCKY SPACE +%d COINS",g); play(S_coin,255); }
            else if(pl[cur].coins<COST){ say("BONE SHOP: NEED 6 COINS"); } }
        if(stT>60){ cur++; stT=0; if(cur>=4){ cur=0; st=ST_INTRO; mg=rand()%3; startMini(); music(1); } else { st=ST_ROLL; say("ROLL THE DICE!"); } } break;
    case ST_INTRO: if(stT==60||stT==110||stT==160) play(S_beep,255); if(stT==210){ play(S_go,255); st=ST_MINI; stT=0; } break;
    case ST_MINI: if(miniUpdate()){ rankAndPay(); st=ST_RES; stT=0; play(S_win,255); } break;
    case ST_RES: if(stT>240){ st=ST_ROLL; stT=0; rnd++; music(0); say("ROLL THE DICE!"); } break;
    case ST_WIN: if(stT>120) for(int p=0;p<4;p++) if(down[p]&ACT){ st=ST_TITLE; } break;
    }
}
// ================= scenes =================
static void camera(float ex,float ey,float ez,float tx,float ty,float tz){
    Mtx v; guVector e={ex,ey,ez},u={0,1,0},t={tx,ty,tz}; guLookAt(v,&e,&u,&t); GX_LoadPosMtxImm(v,GX_PNMTX0);
}
static void pawnPos(int p,float*x,float*y,float*z){
    float x0,z0,x1,z1; int t=pl[p].tile; tpos(t,&x0,&z0); tpos((t+1)%NT,&x1,&z1); float f=0,hy=0;
    if(st==ST_MOVE && p==cur && hop>0 && steps>0){ f=hop/14.f; hy=sinf(f*3.14159f)*1.3f; }
    *x=x0+(x1-x0)*f+(p%2-0.5f)*0.7f; *z=z0+(z1-z0)*f+(p/2-0.5f)*0.7f; *y=0.05f+hy;
}
static void drawBoard(void){
    float px,py,pz; pawnPos(cur,&px,&py,&pz); cx+=(px-cx)*0.05f; cz+=(pz-cz)*0.05f;
    camera(cx*0.5f,13,cz*0.5f+13,cx*0.5f,0,cz*0.5f);
    box(0,-0.9f,0,24,0.5f,20,(C){60,150,70}); box(0,-0.45f,0,14,0.2f,10.5f,(C){90,180,95});
    for(int i=0;i<NT;i++){ float x,z; tpos(i,&x,&z); box(x,-0.4f,z,2.1f,0.4f,2.1f,TC[TT[i]]);
        if(TT[i]==2) bone3d(x,0.7f+sinf(fr*0.08f)*0.15f,z,fr*0.04f,1.1f,GOLD); }
    float ax=0,az=0; if(st!=ST_TITLE){ float tx,ty,tz; pawnPos(cur,&tx,&ty,&tz); ax=atan2f(tx,tz); }
    alfie3d(0,-0.25f,0,ax,0,st==ST_WIN||st==ST_TITLE); (void)az;
    for(int p=0;p<4;p++){ float x,y,z; pawnPos(p,&x,&y,&z); mii(x,y,z,p==cur?0:0.4f,p,st==ST_MOVE&&p==cur?fr*0.5f:0,p==winner&&st==ST_WIN); }
    if(st==ST_ROLL||(st==ST_MOVE&&hop<0)){ float a=fr*0.2f; box(cx*0.5f,5.5f+sinf(fr*0.3f)*0.3f,cz*0.5f+6,1.8f,1.8f,1.8f,WHITE); (void)a; }
}
static void drawFetch(void){
    float lead=0; for(int p=0;p<4;p++) if(mpos[p]>lead) lead=mpos[p];
    camera(lead*0.9f+4,6,13,lead*0.9f+8,1,0);
    box(25,-0.5f,0,90,0.4f,12,(C){150,110,70}); box(50,0,0,0.5f,0.1f,10,WHITE); box(50.5f,0,0,0.3f,3,10,(C){255,255,255});
    for(int p=0;p<4;p++){ float z=(p-1.5f)*2.3f; box(25,-0.1f,z-1.05f,90,0.05f,0.1f,WHITE); mii(mpos[p],0,z,1.5708f,p,mpos[p]*3,0); }
}
static void drawCatch(void){
    camera(0,8,24,0,4.5f,0);
    for(int p=0;p<4;p++){ float zx=(p-1.5f)*7; box(zx,-0.4f,0,6.2f,0.4f,3,PC[p]);
        mii(zx+mpos[p],0,0,mact[p]>0?fr*0.6f:0,p,0,mact[p]>0);
        for(int k=0;k<24;k++){ float y=itemY(k,mt); if(mt<k*42+40||y<0||y>12||cgot[p][k]) continue; float x=zx+itemCol(k);
            if(itemType(k)){ box(x,y,0,0.6f,0.6f,0.3f,(C){200,50,50}); box(x,y+0.2f,0,0.62f,0.18f,0.32f,WHITE); } else bone3d(x,y,0,fr*0.1f,0.9f,WHITE); } }
}
static void drawTiming(void){
    camera(0,13,11,0,0,1);
    for(int p=0;p<4;p++){ float z=(p-1.5f)*3.0f; box(0,-0.3f,z,7,0.3f,1.2f,(C){70,70,80}); box(0,0.05f,z,0.5f,0.2f,1.3f,GOLD);
        for(int a=0;a<matt[p];a++) box(mlk[p][a],0.05f,z,0.2f,0.3f,1.0f,PC[p]);
        float m=sinf(mt*(0.05f+0.02f*matt[p]+p*0.004f))*3; if(matt[p]<3) box(m,0.1f,z,0.3f,0.5f,1.1f,WHITE);
        mii(-5.3f,0,z,1.5708f,p,0,matt[p]>=3); }
}
static void hud(void){
    for(int p=0;p<4;p++){ float x=10+p*156; C bc=PC[p]; if(p==cur&&(st==ST_ROLL||st==ST_MOVE||st==ST_TILE)) rect2(x-3,401,152,74,WHITE);
        rect2(x,404,146,68,(C){25,25,35}); rect2(x,404,146,8,bc); char b[24]; snprintf(b,24,"%s%s",PN[p],pl[p].human?"":" CPU"); text(b,x+6,418,2,bc);
        snprintf(b,24,"COINS %d",pl[p].coins); text(b,x+6,440,3,WHITE);
        for(int i=0;i<NEED;i++) rect2(x+6+i*22,456,18,10,i<pl[p].bones?GOLD:(C){70,70,80}); }
    if(st==ST_ROLL||st==ST_MOVE||st==ST_TILE||st==ST_RES){ ctext(msg,20,4,WHITE);
        if(st==ST_MOVE||st==ST_ROLL){ char b[8]; snprintf(b,8,"%d",(st==ST_MOVE&&hop>=0)?steps+(hop>=14?0:0):(st==ST_MOVE?1+(fr/3)%6:0)); if(st==ST_MOVE) ctext(b,60,8,GOLD); } }
    if(st==ST_ROLL&&pl[cur].human) ctext("PRESS 2 TO ROLL",100,3,GOLD);
    if(st==ST_TITLE){ ctext("ALFIES GAME NIGHT",40,6,GOLD); ctext("FIRST TO 3 GOLDEN BONES WINS",110,3,WHITE); ctext("PRESS 2 TO START",150,4,WHITE);
        ctext("TURN ON REMOTES FOR PLAYERS. OTHERS ARE CPU",190,2,(C){200,220,255}); }
    if(st==ST_INTRO){ rect2(0,150,640,150,(C){20,20,40}); ctext(MGN[mg],165,7,GOLD); ctext(MGH[mg],235,2,WHITE);
        int n=3-(stT-60)/50; if(stT>=60&&n>0){ char b[4]; snprintf(b,4,"%d",n); ctext(b,270,5,WHITE);} }
    if(st==ST_MINI){ char b[16]; if(stT<40) ctext("GO!",60,8,GOLD); snprintf(b,16,"%d",(int)(mg==0?(mt/60):0)); (void)b;
        for(int p=0;p<4;p++){ char s[16]; snprintf(s,16,"P%d %d",p+1,(int)(mg==0?mpos[p]*2:(mg==1?msc[p]:matt[p]))); text(s,10+p*156,10,3,PC[p]); } }
    if(st==ST_RES){ rect2(100,120,440,200,(C){20,20,40}); ctext("RESULTS",130,6,GOLD);
        for(int r=0;r<4;r++) for(int p=0;p<4;p++) if(rank_[p]==r){ char s[32]; static const int pay[4]={5,3,2,1}; snprintf(s,32,"%s +%d COINS",PN[p],pay[r]); text(s,200,185+(r*30),3,PC[p]); } }
    if(st==ST_WIN){ char s[24]; snprintf(s,24,"%s WINS!",PN[winner]); ctext(s,40,10,GOLD); ctext("PRESS 2 TO PLAY AGAIN",110,3,WHITE); }
}
static void drawScene(void){
    if(st==ST_INTRO||st==ST_MINI||st==ST_RES){ if(mg==0) drawFetch(); else if(mg==1) drawCatch(); else drawTiming(); }
    else drawBoard();
}
// ================= main =================
int main(void){
    VIDEO_Init(); WPAD_Init(); for(int i=0;i<4;i++) WPAD_SetDataFormat(i,WPAD_FMT_BTNS);
    rm=VIDEO_GetPreferredMode(NULL); xfb[0]=MEM_K0_TO_K1(SYS_AllocateFramebuffer(rm)); xfb[1]=MEM_K0_TO_K1(SYS_AllocateFramebuffer(rm));
    VIDEO_Configure(rm); VIDEO_SetNextFramebuffer(xfb[fb]); VIDEO_SetBlack(FALSE); VIDEO_Flush(); VIDEO_WaitVSync(); if(rm->viTVMode&VI_NON_INTERLACE) VIDEO_WaitVSync();
    void*fifo=memalign(32,0x40000); memset(fifo,0,0x40000); GX_Init(fifo,0x40000);
    GXColor bg={120,190,255,255}; GX_SetCopyClear(bg,0x00ffffff); GX_SetViewport(0,0,rm->fbWidth,rm->efbHeight,0,1);
    f32 ys=GX_GetYScaleFactor(rm->efbHeight,rm->xfbHeight); u32 xh=GX_SetDispCopyYScale(ys);
    GX_SetScissor(0,0,rm->fbWidth,rm->efbHeight); GX_SetDispCopySrc(0,0,rm->fbWidth,rm->efbHeight); GX_SetDispCopyDst(rm->fbWidth,xh);
    GX_SetCopyFilter(rm->aa,rm->sample_pattern,GX_TRUE,rm->vfilter); GX_SetFieldMode(rm->field_rendering,((rm->viHeight==2*rm->xfbHeight)?GX_ENABLE:GX_DISABLE));
    GX_SetCullMode(GX_CULL_NONE); GX_CopyDisp(xfb[fb],GX_TRUE); GX_SetDispCopyGamma(GX_GM_1_0);
    GX_ClearVtxDesc(); GX_SetVtxDesc(GX_VA_POS,GX_DIRECT); GX_SetVtxDesc(GX_VA_CLR0,GX_DIRECT);
    GX_SetVtxAttrFmt(GX_VTXFMT0,GX_VA_POS,GX_POS_XYZ,GX_F32,0); GX_SetVtxAttrFmt(GX_VTXFMT0,GX_VA_CLR0,GX_CLR_RGBA,GX_RGBA8,0);
    GX_SetNumChans(1); GX_SetNumTexGens(0); GX_SetTevOrder(GX_TEVSTAGE0,GX_TEXCOORDNULL,GX_TEXMAP_NULL,GX_COLOR0A0); GX_SetTevOp(GX_TEVSTAGE0,GX_PASSCLR);
    Mtx44 persp,ortho; guPerspective(persp,55,(f32)rm->fbWidth/rm->efbHeight,0.5f,300); guOrtho(ortho,0,479,0,639,0,300);
    initSound(); st=ST_TITLE; music(0);
    while(1){
        WPAD_ScanPads(); for(int p=0;p<4;p++){ u32 ty; pl[p].human=(WPAD_Probe(p,&ty)==WPAD_ERR_NONE); held[p]=pl[p].human?WPAD_ButtonsHeld(p):0; down[p]=pl[p].human?WPAD_ButtonsDown(p):0; }
        for(int p=0;p<4;p++){
            if(down[p]&WPAD_BUTTON_HOME) exit(0);
            if(st!=ST_TITLE&&(down[p]&WPAD_BUTTON_MINUS)){ st=ST_TITLE; stT=0; music(0); }
        }
        fr++; update();
        GX_SetViewport(0,0,rm->fbWidth,rm->efbHeight,0,1);
        GX_LoadProjectionMtx(persp,GX_PERSPECTIVE); GX_SetZMode(GX_TRUE,GX_LEQUAL,GX_TRUE); drawScene();
        Mtx id; guMtxIdentity(id); GX_LoadPosMtxImm(id,GX_PNMTX0); GX_LoadProjectionMtx(ortho,GX_ORTHOGRAPHIC); GX_SetZMode(GX_FALSE,GX_ALWAYS,GX_FALSE); hud();
        GX_DrawDone(); fb^=1; GX_SetColorUpdate(GX_TRUE); GX_CopyDisp(xfb[fb],GX_TRUE); VIDEO_SetNextFramebuffer(xfb[fb]); VIDEO_Flush(); VIDEO_WaitVSync();
    }
    return 0;
}
